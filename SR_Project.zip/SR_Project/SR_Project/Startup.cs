﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SR_Project.Startup))]
namespace SR_Project
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
