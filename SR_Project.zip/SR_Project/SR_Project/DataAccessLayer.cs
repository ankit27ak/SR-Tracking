﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;
using System.Data;
using System.Configuration;
using SR_Project.Models;

namespace SR_Project
{
    public class DataAccessLayer
    {
        public string GetPasswordForUserAuthentication(int uname)
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            conn.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@param1", uname);
            comm.CommandText = "SELECT password from usertable where username = @param1;";
            string checkpassword = Convert.ToString(comm.ExecuteScalar());
            comm.Dispose();
            conn.Close();
            return checkpassword;
        }

        public int RegisterNewUser(UserClass obj)
        {
            int uname = obj.name;
            string pass = obj.password;
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            conn.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@param1", uname);
            comm.Parameters.AddWithValue("@param2", pass);
            comm.CommandText = "INSERT INTO usertable(username,password) VALUES(@param1,@param2);";

            return comm.ExecuteNonQuery();

        }

        public void InserSrInDataBase(SrClass obj)
        {
            string srNumber = obj.srNumber;
            string srType = obj.srType;
            string severity = obj.severity;
            int createdBy = obj.createdBy;
            DateTime severityAssignDate = obj.severityAssignDate;
            string status = obj.status;
            string problemType = obj.problemType;
            DateTime ir = obj.ir;
            DateTime pr = obj.pr;
            string failureType = obj.failureType;
            int oobfQuantity = obj.oobfQuantity;
            int icfQuantity = obj.icfQuantity;
            string softwareVersionNumber = obj.softwareVersionNumber;
            string resolutionType = obj.resolutionType;
            string resolutionSummary;
            if (obj.resolutionSummary == null)
            {
                resolutionSummary = "Not Avilable";
            }
            else
            {
                resolutionSummary = obj.resolutionSummary;
            }
            
            string note = obj.note;
            string attachment = obj.attachment;
            int srid = obj.srid;

            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            conn.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@param1", srNumber);
            comm.Parameters.AddWithValue("@param2", severity);
            comm.Parameters.AddWithValue("@param3", severityAssignDate);
            comm.Parameters.AddWithValue("@param4", srType);
            comm.Parameters.AddWithValue("@param5", status);
            comm.Parameters.AddWithValue("@param6", problemType);
            comm.Parameters.AddWithValue("@param7", ir);
            comm.Parameters.AddWithValue("@param8", pr);
            comm.Parameters.AddWithValue("@param9", failureType);
            comm.Parameters.AddWithValue("@param10", oobfQuantity);
            comm.Parameters.AddWithValue("@param11", icfQuantity);
            comm.Parameters.AddWithValue("@param12", softwareVersionNumber);
            comm.Parameters.AddWithValue("@param13", resolutionType);
            comm.Parameters.AddWithValue("@param14", createdBy);
            comm.Parameters.AddWithValue("@param15", note);
            comm.Parameters.AddWithValue("@param16", srid);
            comm.Parameters.AddWithValue("@param17", resolutionSummary);
            comm.Parameters.AddWithValue("@param18", attachment);



            comm.CommandText = "INSERT INTO srtable(srnumber,severity,severityassigndate,srtype,status,problelmtype,irdate,prdate,failuretype,oobfquantity,icfquantity,softwareversionnumber,resolutiontype,createdby,note,srid,resolutionsummary,attachment) VALUES(@param1,@param2,@param3,@param4,@param5,@param6,@param7,@param8,@param9,@param10,@param11,@param12,@param13,@param14,@param15,@param16,@param17,@param18);";

            comm.ExecuteNonQuery();
            comm.Dispose();
            conn.Close();




        }

        public List<ResolutionType> BindResolutionFromDatabase()
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();

            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT * FROM resolutiontypetable;";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(comm);
            da.Fill(ds);
            List<ResolutionType> resolutionlist = new List<ResolutionType>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                ResolutionType reobj = new ResolutionType();
                reobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                reobj.resolutionType = Convert.ToString(ds.Tables[0].Rows[i]["resolutiontype"].ToString());

                resolutionlist.Add(reobj);
            }
            da.Dispose();
            comm.Dispose();
            conn.Close();
            return resolutionlist;


        }

        public List<SrProblemType> BindProblemTypeFromDatabase()
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();

            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT * FROM problemtypetable;";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(comm);
            da.Fill(ds);
            List<SrProblemType> srProblemList = new List<SrProblemType>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                SrProblemType probj = new SrProblemType();
                probj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                probj.problemType = Convert.ToString(ds.Tables[0].Rows[i]["problemtype"].ToString());

                srProblemList.Add(probj);
            }
            da.Dispose();
            comm.Dispose();
            conn.Close();
            return srProblemList;


        }

        public List<SrType> BindSrTypeFromDatabase()
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();

            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT * FROM srtypetable;";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(comm);
            da.Fill(ds);
            List<SrType> srList = new List<SrType>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                SrType srTypeobj = new SrType();
                srTypeobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                srTypeobj.srType = Convert.ToString(ds.Tables[0].Rows[i]["srtype"].ToString());

                srList.Add(srTypeobj);
            }
            da.Dispose();
            comm.Dispose();
            conn.Close();
            return srList;


        }

        public List<SrStatus> BindSrStatusTypeFromDatabase()
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();

            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT * FROM statustable;";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(comm);
            da.Fill(ds);
            List<SrStatus> srStatusList = new List<SrStatus>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                SrStatus srStatusobj = new SrStatus();
                srStatusobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                srStatusobj.status = Convert.ToString(ds.Tables[0].Rows[i]["status"].ToString());

                srStatusList.Add(srStatusobj);
            }
            da.Dispose();
            comm.Dispose();
            conn.Close();
            return srStatusList;


        }

        public List<SrClass> GetAllSrFromDatabase()
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();

            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT srid,srnumber,severity,severityassigndate,srtype,status,problelmtype,createdby FROM srtable;";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(comm);
            da.Fill(ds);
            List<SrClass> srList = new List<SrClass>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                SrClass srClassobj = new SrClass();
                srClassobj.srid = Convert.ToInt32(ds.Tables[0].Rows[i]["srid"].ToString());
                srClassobj.srNumber = Convert.ToString(ds.Tables[0].Rows[i]["srnumber"].ToString());
                srClassobj.severity = Convert.ToString(ds.Tables[0].Rows[i]["severity"].ToString());
                srClassobj.severityAssignDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["severityassigndate"].ToString());
                srClassobj.srType = Convert.ToString(ds.Tables[0].Rows[i]["srtype"].ToString());
                srClassobj.status = Convert.ToString(ds.Tables[0].Rows[i]["status"].ToString());
                srClassobj.problemType = Convert.ToString(ds.Tables[0].Rows[i]["problelmtype"].ToString());
                srClassobj.createdBy = Convert.ToInt32(ds.Tables[0].Rows[i]["createdby"].ToString());
                srList.Add(srClassobj);
            }
            da.Dispose();
            comm.Dispose();
            conn.Close();
            return srList;


        }

        public SrClass GetFullCompleteSRFromDatabase(int id)
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();

            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@param1", id);
            comm.CommandText = "SELECT srid,srnumber,severity,severityassigndate,srtype,status,problelmtype,createdby,irdate,prdate,failuretype,oobfquantity,icfquantity,softwareversionnumber,resolutiontype,resolutionsummary,note FROM srtable where srid = @param1;";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(comm);
            da.Fill(ds);
            SrClass sr = new SrClass();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                SrClass srClassobj = new SrClass();
                srClassobj.srid = Convert.ToInt32(ds.Tables[0].Rows[i]["srid"].ToString());
                srClassobj.srNumber = Convert.ToString(ds.Tables[0].Rows[i]["srnumber"].ToString());
                srClassobj.severity = Convert.ToString(ds.Tables[0].Rows[i]["severity"].ToString());
                srClassobj.severityAssignDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["severityassigndate"].ToString());
                srClassobj.srType = Convert.ToString(ds.Tables[0].Rows[i]["srtype"].ToString());
                srClassobj.status = Convert.ToString(ds.Tables[0].Rows[i]["status"].ToString());
                srClassobj.problemType = Convert.ToString(ds.Tables[0].Rows[i]["problelmtype"].ToString());
                srClassobj.createdBy = Convert.ToInt32(ds.Tables[0].Rows[i]["createdby"].ToString());
                srClassobj.ir = Convert.ToDateTime(ds.Tables[0].Rows[i]["irdate"].ToString());
                srClassobj.pr = Convert.ToDateTime(ds.Tables[0].Rows[i]["prdate"].ToString());
                srClassobj.failureType = Convert.ToString(ds.Tables[0].Rows[i]["failuretype"].ToString());
                srClassobj.oobfQuantity = Convert.ToInt32(ds.Tables[0].Rows[i]["oobfquantity"].ToString());
                srClassobj.icfQuantity = Convert.ToInt32(ds.Tables[0].Rows[i]["icfquantity"].ToString());
                srClassobj.softwareVersionNumber = Convert.ToString(ds.Tables[0].Rows[i]["softwareversionnumber"].ToString());
                srClassobj.resolutionType = Convert.ToString(ds.Tables[0].Rows[i]["resolutiontype"].ToString());
                srClassobj.resolutionSummary = Convert.ToString(ds.Tables[0].Rows[i]["resolutionsummary"].ToString());
                srClassobj.note = Convert.ToString(ds.Tables[0].Rows[i]["note"].ToString());

                sr = srClassobj;
            }
            da.Dispose();
            comm.Dispose();
            conn.Close();
            return sr;
        }

        public void AddResolutionSummary(ViewModel obj)
        {
            string resolutionsummary = obj.srclasobj.resolutionSummary;
            int srid = obj.srclasobj.srid;
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            conn.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@param1", resolutionsummary);
            comm.Parameters.AddWithValue("@param2", srid);

            comm.CommandText = "UPDATE srtable SET resolutionsummary = @param1 where srid = @param2;";

            comm.ExecuteNonQuery();
            comm.Dispose();
            conn.Close();
        }

        public void InserNoteInDataBase(NoteClass obj)
        {
            string note = obj.note;
            DateTime date = obj.date;
            string addBy = obj.addBy;
            int srid = obj.srid;
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            conn.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@param1", srid);
            comm.Parameters.AddWithValue("@param2", date);
            comm.Parameters.AddWithValue("@param3", note);
            comm.Parameters.AddWithValue("@param4", addBy);

            comm.CommandText = "INSERT INTO notetable(srid,date,note,addby) VALUES(@param1,@param2,@param3,@param4);";

            comm.ExecuteNonQuery();
            comm.Dispose();
            conn.Close();
        }

        //GetNotesForParticularSRFromDataBase
        public List<NoteClass> GetNotesForParticularSRFromDataBase(int id)
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();

            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@param1", id);
            comm.CommandText = "SELECT srid,date,note,addby FROM notetable WHERE srid = @param1;";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(comm);
            da.Fill(ds);
            List<NoteClass> noteList = new List<NoteClass>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                NoteClass noteClassobj = new NoteClass();
                noteClassobj.srid = Convert.ToInt32(ds.Tables[0].Rows[i]["srid"].ToString());
                noteClassobj.date = Convert.ToDateTime(ds.Tables[0].Rows[i]["date"].ToString());
                noteClassobj.note = Convert.ToString(ds.Tables[0].Rows[i]["note"].ToString());
                noteClassobj.addBy = Convert.ToString(ds.Tables[0].Rows[i]["addby"].ToString());
                
                noteList.Add(noteClassobj);
            }
            da.Dispose();
            comm.Dispose();
            conn.Close();
            return noteList;


        }

        public List<SrClass> FilterSrByDate(DateTime date)
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();

            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@param1", date);
            comm.CommandText = "SELECT srid,srnumber,severity,severityassigndate,srtype,status,problelmtype,createdby FROM srtable where severityassigndate = @param1;";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(comm);
            da.Fill(ds);
            List<SrClass> srList = new List<SrClass>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                SrClass srClassobj = new SrClass();
                srClassobj.srid = Convert.ToInt32(ds.Tables[0].Rows[i]["srid"].ToString());
                srClassobj.srNumber = Convert.ToString(ds.Tables[0].Rows[i]["srnumber"].ToString());
                srClassobj.severity = Convert.ToString(ds.Tables[0].Rows[i]["severity"].ToString());
                srClassobj.severityAssignDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["severityassigndate"].ToString());
                srClassobj.srType = Convert.ToString(ds.Tables[0].Rows[i]["srtype"].ToString());
                srClassobj.status = Convert.ToString(ds.Tables[0].Rows[i]["status"].ToString());
                srClassobj.problemType = Convert.ToString(ds.Tables[0].Rows[i]["problelmtype"].ToString());
                srClassobj.createdBy = Convert.ToInt32(ds.Tables[0].Rows[i]["createdby"].ToString());
                srList.Add(srClassobj);
            }
            da.Dispose();
            comm.Dispose();
            conn.Close();
            return srList;
        }

        public List<SrClass> FilterSrBySRNumber(string srnumber)
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();

            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@param1", srnumber);
            comm.CommandText = "SELECT srid,srnumber,severity,severityassigndate,srtype,status,problelmtype,createdby FROM srtable where srnumber = @param1;";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(comm);
            da.Fill(ds);
            List<SrClass> srList = new List<SrClass>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                SrClass srClassobj = new SrClass();
                srClassobj.srid = Convert.ToInt32(ds.Tables[0].Rows[i]["srid"].ToString());
                srClassobj.srNumber = Convert.ToString(ds.Tables[0].Rows[i]["srnumber"].ToString());
                srClassobj.severity = Convert.ToString(ds.Tables[0].Rows[i]["severity"].ToString());
                srClassobj.severityAssignDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["severityassigndate"].ToString());
                srClassobj.srType = Convert.ToString(ds.Tables[0].Rows[i]["srtype"].ToString());
                srClassobj.status = Convert.ToString(ds.Tables[0].Rows[i]["status"].ToString());
                srClassobj.problemType = Convert.ToString(ds.Tables[0].Rows[i]["problelmtype"].ToString());
                srClassobj.createdBy = Convert.ToInt32(ds.Tables[0].Rows[i]["createdby"].ToString());
                srList.Add(srClassobj);
            }
            da.Dispose();
            comm.Dispose();
            conn.Close();
            return srList;
        }

    }
}