﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SR_Project.Models;
using Npgsql;
using System.Data;
using System.Configuration;
using System.IO;
using OfficeOpenXml;

namespace SR_Project
{
    public class BusinessLayer
    {
        public bool checkvaliduser(UserClass userobj)
        {
            int uname = userobj.name;
            string pass = userobj.password;
            DataAccessLayer obj = new DataAccessLayer();

            string checkpassword = obj.GetPasswordForUserAuthentication(uname);
            if (checkpassword == pass)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string registerUser(UserClass userobj)
        {

            DataAccessLayer obj = new DataAccessLayer();
            int result = obj.RegisterNewUser(userobj);
            if (result == 1)
                return "User register successfully";
            else
                return "User not register successfully";

        }

        public List<ResolutionType> bindResolutionType()
        {
            DataAccessLayer obj = new DataAccessLayer();
            List<ResolutionType> resolutionList = new List<ResolutionType>();
            resolutionList = obj.BindResolutionFromDatabase();
            return resolutionList;

        }

        public List<SrProblemType> bindSrProblemType()
        {
            DataAccessLayer obj = new DataAccessLayer();
            List<SrProblemType> srProblemList = new List<SrProblemType>();
            srProblemList = obj.BindProblemTypeFromDatabase();
            return srProblemList;

        }

        public List<SrType> bindSrType()
        {
            DataAccessLayer obj = new DataAccessLayer();
            List<SrType> srtypeList = new List<SrType>();
            srtypeList = obj.BindSrTypeFromDatabase();
            return srtypeList;

        }

        public List<SrStatus> bindSrStatusType()
        {
            DataAccessLayer obj = new DataAccessLayer();
            List<SrStatus> srStatusList = new List<SrStatus>();
            srStatusList = obj.BindSrStatusTypeFromDatabase();
            return srStatusList;

        }

        public List<SrClass> GetAllSr()
        {
            DataAccessLayer obj = new DataAccessLayer();
            List<SrClass> srList = new List<SrClass>();
            srList = obj.GetAllSrFromDatabase();
            return srList;

        }

        public SrClass GetFullCompleteSr(int id)
        {
            DataAccessLayer obj = new DataAccessLayer();
            SrClass sr = new SrClass();
            sr = obj.GetFullCompleteSRFromDatabase(id);
            return sr;

        }

        public void InsertSR(SrClass obj)
        {
            DataAccessLayer DataAccessLayerobj = new DataAccessLayer();
            DataAccessLayerobj.InserSrInDataBase(obj);
        }

        public void AddResolutionSummary(ViewModel obj)
        {
            DataAccessLayer DataAccessLayerobj = new DataAccessLayer();
            DataAccessLayerobj.AddResolutionSummary(obj);

        }

        public void Addnote(NoteClass obj)
        {
            NoteClass noteclassobj = new NoteClass();
            noteclassobj.note = obj.note;
            noteclassobj.srid = obj.srid;
            noteclassobj.date = DateTime.Now;
            noteclassobj.addBy = obj.addBy;
            DataAccessLayer DataAccessLayerobj = new DataAccessLayer();
            DataAccessLayerobj.InserNoteInDataBase(noteclassobj);

        }

        public List<NoteClass> GetNotesOfSR(int id)
        {
            List<NoteClass> noteList = new List<NoteClass>();
            DataAccessLayer DataAccessLayerobj = new DataAccessLayer();
            noteList = DataAccessLayerobj.GetNotesForParticularSRFromDataBase(id);
            return noteList;
        }

        public List<SrClass> filterSRByDate(ViewModel obj)
        {
            DateTime selectedDate = obj.srclasobj.severityAssignDate;
            DataAccessLayer DataAccessLayerobj = new DataAccessLayer();
            List<SrClass> srlist = DataAccessLayerobj.FilterSrByDate(selectedDate);
            return srlist;
        }

        public List<SrClass> filterSRBySRNumber(ViewModel obj)
        {
            string selectedSRNumber = obj.srclasobj.srNumber;
            DataAccessLayer DataAccessLayerobj = new DataAccessLayer();
            List<SrClass> srlist = DataAccessLayerobj.FilterSrBySRNumber(selectedSRNumber);
            return srlist;
        }



    }
}
