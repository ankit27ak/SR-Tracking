﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SR_Project.Models;

namespace SR_Project.Models
{
    public class MultipleModelInOneView
    {
        public class SrClass
        {
          //  [Required(ErrorMessage = "SR Number is Required.")]
            public string srNumber { get; set; }


           // [Required(ErrorMessage = "SR Type is Required.")]
            public string srType { get; set; }


         //   [Required(ErrorMessage = "Severity is Required.")]
            public string severity { get; set; }


         //   [Required(ErrorMessage = "CreatedBy is Required.")]
            public string createdBy { get; set; }

         //   [Required(ErrorMessage = "SeverityAssignDate Required.")]
            public DateTime severityAssignDate { get; set; }

         //   [Required(ErrorMessage = "Status is Required.")]
            public string status { get; set; }


          //  [Required(ErrorMessage = "Problem Type is Required.")]
            public string problemType { get; set; }


          //  [Required(ErrorMessage = "Ir Date  is Required.")]
            public DateTime ir { get; set; }


           // [Required(ErrorMessage = "PR Date is Required.")]
            public DateTime pr { get; set; }


          //  [Required(ErrorMessage = "Failure Type is Required.")]
            public string failureType { get; set; }


            //[Required(ErrorMessage = "OobfQuanatity is Required.")]
            public int oobfQuantity { get; set; }


           // [Required(ErrorMessage = "Icf Quantity is Required.")]
            public int icfQuantity { get; set; }


            
            public string softwareVersionNumber { get; set; }


            
            public string resolutionType { get; set; }


            
            public string resolutionSummary { get; set; }


           
            public string note { get; set; }


           
            public string attachment { get; set; }
        }

        public class ResolutionType
        {
            public int id { get; set; }
            public string resolutionType { get; set; }

        }

        public class ViewModel
        {
            public List<SrClass> SrClassList { get; set; }
            public List<ResolutionType> ResolutionTypeList { get; set; }
        }

    }
}