﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SR_Project.Models
{
    public class ViewModel
    {
        public SrClass srclasobj { get; set; }
        public List<SrClass> SrList { get; set; }
        public List<ResolutionType> ResolutionTypeList { get; set; }
        public List<SrStatus> SrStatusList { get; set; }
        public List<SrType> SrTypeList { get; set; }
        public List<SrProblemType> SrProblemTypeList { get; set; }
        public NoteClass NoteClassobj { get; set; }
        public List<NoteClass> NoteClassList { get; set; }
    }
}