﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using System.ComponentModel.DataAnnotations;

namespace SR_Project.Models
{
    public class UserClass
    {
        public int name { get; set; }
        public string password { get; set; }

        [Compare("password", ErrorMessage = "Both Password and Confirm Password Must be Same")]
        public string ConfirmPassword { get; set; }
    }
}