﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SR_Project.Models
{
    public class SrProblemType
    {
        public int id { get; set; }
        public string problemType { get; set; }
    }
}