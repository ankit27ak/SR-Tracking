﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SR_Project.Models
{
    public class NoteClass
    {
        public int srid { get; set; }
        public DateTime date { get; set; }
        public string note { get; set; }
        public string addBy { get; set; }
    }
}