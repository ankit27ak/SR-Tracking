﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SR_Project.Models
{
    public class SrStatus
    {
        public int id { get; set; }
        public string status { get; set; }
        
    }
}