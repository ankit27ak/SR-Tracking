﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SR_Project.Models
{
    public class ResolutionType
    {
        public int id  { get; set;}
        public string resolutionType { get; set; }
       
    }
}