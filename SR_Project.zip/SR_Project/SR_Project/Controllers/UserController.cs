﻿
using System.Web.Mvc;
using SR_Project.Models;
using System.Configuration;
using Npgsql;
using System.Data;
using OfficeOpenXml;
using System.IO;


namespace SR_Project.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult loginview()
        {
            return View();

        }

        // POST: user
        [HttpPost]
        public ActionResult loginview(UserClass obj)
        {

            return userafterloginview(obj);
        }

        [HttpPost]
        public ActionResult userafterloginview(UserClass obj)
        {
            BusinessLayer businesslayerobj = new BusinessLayer();
            bool x = businesslayerobj.checkvaliduser(obj);
            if (x == true)

                return RedirectToAction("showSr", "User");
            else
                return RedirectToAction("userRegistrationView", "User");
            // return userRegistrationView();
            //return View(userobj);

        }

        // GET: User
        public ActionResult userRegistrationView()
        {
            return View();

        }

        // POST: user
        [HttpPost]
        public ActionResult userRegistrationView(UserClass obj)
        {
            BusinessLayer businesslayerobj = new BusinessLayer();
            string x = businesslayerobj.registerUser(obj);

            return View();
        }

        public ActionResult afterlogin()
        {
            ViewModel VM = new ViewModel();
            BusinessLayer businesslayerobj = new BusinessLayer();
            VM.ResolutionTypeList = businesslayerobj.bindResolutionType();
            VM.SrProblemTypeList = businesslayerobj.bindSrProblemType();
            VM.SrTypeList = businesslayerobj.bindSrType();
            VM.SrStatusList = businesslayerobj.bindSrStatusType();
            //BCVM.srclasobj = GetCommentModel();
            return View(VM);


        }

        [HttpPost]
        public ActionResult afterlogin(ViewModel obj)
        {
            SrClass SrClassobj = obj.srclasobj;
            BusinessLayer businesslayerobj = new BusinessLayer();
            businesslayerobj.InsertSR(SrClassobj);
            return View();
        }

        public ActionResult showSr()
        {
            ViewModel VM = new ViewModel();
            BusinessLayer businesslayerobj = new BusinessLayer();
            VM.SrList = businesslayerobj.GetAllSr();
            return View(VM);
        }

        public ActionResult ExpendSr(int id)
        {
            ViewModel VM = new ViewModel();
            BusinessLayer businesslayerobj = new BusinessLayer();
            VM.srclasobj = businesslayerobj.GetFullCompleteSr(id);
            VM.NoteClassList = businesslayerobj.GetNotesOfSR(id);
            return View(VM);
        }

        public ActionResult Add_Note(int id)
        {
            ViewBag.id = id;
            return View();
        }

        [HttpPost]
        public ActionResult AddNote(NoteClass obj)
        {
            
            BusinessLayer businesslayerobj = new BusinessLayer();
            businesslayerobj.Addnote(obj);
            return RedirectToAction("showSr", "User");
        }

        public ActionResult AddResolutionSummary(int id)
        {
            ViewBag.id = id;
            return View();
        }
        public ActionResult AddResolutionSumm(ViewModel obj)
        {
            BusinessLayer businesslayerobj = new BusinessLayer();
            businesslayerobj.AddResolutionSummary(obj);
            return RedirectToAction("showSr", "User");

        }


        public ActionResult CreateCSV()
        {
            string cs = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            NpgsqlConnection conn = new NpgsqlConnection(cs);
            DataSet ds = new DataSet();
            conn.Open();
            DataTable dt = new DataTable();
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            NpgsqlDataAdapter ad = new NpgsqlDataAdapter("select * from srtable", conn);
            ad.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                string filepath = Server.MapPath("~/Content/SR_Report.xlsx");
                using (var package = new ExcelPackage(new FileInfo(filepath)))
                {
                    var sheetcreate = package.Workbook.Worksheets.Add("SR_Report" + System.DateTime.Now.Ticks.ToString());



                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        sheetcreate.Cells[1, i + 1].Value = dt.Columns[i].ColumnName.ToString();
                    }
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        for (int j = 0; j < dt.Columns.Count; j++)
                        {
                            sheetcreate.Cells[i + 2, j + 1].Value = dt.Rows[i][j].ToString();
                        }
                    }
                    package.Save();
                }

            }
            return View();
        }

        //Get
        public ActionResult filterSr()
        {

            return View();
        }

        
        public ActionResult filterSRByDate(ViewModel obj)
        {
            BusinessLayer businesslayerobj = new BusinessLayer();
            ViewModel VM = new ViewModel();
            VM.SrList = businesslayerobj.filterSRByDate(obj);
           


            return View(VM);
        }

        public ActionResult filterSRBySRNumber(ViewModel obj)
        {
            BusinessLayer businesslayerobj = new BusinessLayer();
            ViewModel VM = new ViewModel();
            VM.SrList = businesslayerobj.filterSRBySRNumber(obj);
            


            return View(VM);
        }


    }
}